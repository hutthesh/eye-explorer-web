import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { LandingPage } from './pages/LandingPage';
import { UserLogin } from './pages/UserLogin';
import { ScientistLogin } from './pages/ScientistLogin';
import { UserDashboard } from './pages/user/UserDashboard';
import { Weather } from './pages/user/Weather';
import { ExploreData } from './pages/user/ExploreData';
import { Annotations } from './pages/user/Annotations';
import { AIBot } from './pages/user/AIBot';
import { Favorites } from './pages/user/Favorites';
import { Timelapse } from './pages/user/Timelapse';
import { Profile } from './pages/user/Profile';
import { Contact } from './pages/user/Contact';
import { ScientistDashboard } from './pages/scientist/ScientistDashboard';
import { DatasetExplorer } from './pages/scientist/DatasetExplorer';
import { AIModels } from './pages/scientist/AIModels';
import { Analytics } from './pages/scientist/Analytics';
import { Research } from './pages/scientist/Research';
import { Collaborations } from './pages/scientist/Collaborations';
import { Admin } from './pages/scientist/Admin';
import { AIResearch } from './pages/scientist/AIResearch';
import { ScientistProfile } from './pages/scientist/Profile';
import { Support } from './pages/scientist/Support';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login/user" element={<UserLogin />} />
          <Route path="/login/scientist" element={<ScientistLogin />} />

          <Route
            path="/user/dashboard"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <UserDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/weather"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Weather />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/explore"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <ExploreData />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/annotations"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Annotations />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/ai-bot"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <AIBot />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/favorites"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Favorites />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/timelapse"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Timelapse />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/profile"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/contact"
            element={
              <ProtectedRoute requiredRole="normal_user">
                <Contact />
              </ProtectedRoute>
            }
          />

          <Route
            path="/scientist/dashboard"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <ScientistDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/datasets"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <DatasetExplorer />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/ai-models"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <AIModels />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/analytics"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <Analytics />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/research"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <Research />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/collaborations"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <Collaborations />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/admin"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <Admin />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/ai-research"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <AIResearch />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/profile"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <ScientistProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/scientist/support"
            element={
              <ProtectedRoute requiredRole="nasa_scientist">
                <Support />
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
