import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import {
  Home,
  Cloud,
  Database,
  BookmarkPlus,
  Bot,
  Star,
  Film,
  User,
  Mail,
  LogOut,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  Microscope,
  Users,
  Settings,
  HelpCircle,
  FileText,
  Brain,
} from 'lucide-react';

interface SidebarProps {
  role: 'normal_user' | 'nasa_scientist';
}

export const Sidebar: React.FC<SidebarProps> = ({ role }) => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const userMenuItems = [
    { icon: Home, label: 'Home', path: '/user/dashboard' },
    { icon: Cloud, label: 'Weather & Space', path: '/user/weather' },
    { icon: Database, label: 'Explore Data', path: '/user/explore' },
    { icon: BookmarkPlus, label: 'Annotations', path: '/user/annotations' },
    { icon: Bot, label: 'AI Explorer Bot', path: '/user/ai-bot' },
    { icon: Star, label: 'Favorites', path: '/user/favorites' },
    { icon: Film, label: 'Time-lapse', path: '/user/timelapse' },
    { icon: User, label: 'Profile', path: '/user/profile' },
    { icon: Mail, label: 'Contact', path: '/user/contact' },
  ];

  const scientistMenuItems = [
    { icon: Home, label: 'Dashboard', path: '/scientist/dashboard' },
    { icon: Database, label: 'Dataset Explorer', path: '/scientist/datasets' },
    { icon: Brain, label: 'AI Models', path: '/scientist/ai-models' },
    { icon: BarChart3, label: 'Data Analytics', path: '/scientist/analytics' },
    { icon: FileText, label: 'Research Insights', path: '/scientist/research' },
    { icon: Users, label: 'Collaborations', path: '/scientist/collaborations' },
    { icon: Settings, label: 'Admin Tools', path: '/scientist/admin' },
    { icon: Microscope, label: 'AI Research', path: '/scientist/ai-research' },
    { icon: User, label: 'Profile', path: '/scientist/profile' },
    { icon: HelpCircle, label: 'Support', path: '/scientist/support' },
  ];

  const menuItems = role === 'normal_user' ? userMenuItems : scientistMenuItems;
  const gradientClass =
    role === 'normal_user'
      ? 'from-blue-600 to-cyan-500'
      : 'from-emerald-600 to-teal-500';

  return (
    <motion.div
      initial={{ x: -300 }}
      animate={{ x: 0, width: collapsed ? '80px' : '280px' }}
      transition={{ duration: 0.3 }}
      className="fixed left-0 top-0 h-screen bg-slate-900/95 backdrop-blur-xl border-r border-gray-700 z-50 flex flex-col"
    >
      <div className="p-6 flex items-center justify-between border-b border-gray-700">
        <AnimatePresence mode="wait">
          {!collapsed && (
            <motion.h2
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className={`text-xl font-bold bg-gradient-to-r ${gradientClass} bg-clip-text text-transparent`}
            >
              {role === 'normal_user' ? 'Explorer' : 'NASA Portal'}
            </motion.h2>
          )}
        </AnimatePresence>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-gray-400 hover:text-white"
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-6 px-3 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <Link key={item.path} to={item.path}>
              <motion.div
                whileHover={{ scale: 1.02, x: 4 }}
                whileTap={{ scale: 0.98 }}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? `bg-gradient-to-r ${gradientClass} text-white shadow-lg`
                    : 'text-gray-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <AnimatePresence mode="wait">
                  {!collapsed && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="font-medium whitespace-nowrap"
                    >
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </motion.div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-700">
        <motion.button
          onClick={handleLogout}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center gap-3 w-full px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all"
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="font-medium whitespace-nowrap"
              >
                Logout
              </motion.span>
            )}
          </AnimatePresence>
        </motion.button>
      </div>
    </motion.div>
  );
};
