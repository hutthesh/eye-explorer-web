import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Starfield } from '../components/Starfield';
import { Telescope, UserCircle } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Starfield />

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="text-center mb-16"
        >
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-cyan-300 to-blue-500 bg-clip-text text-transparent drop-shadow-2xl">
            Embiggen Your Eyes Explorer
          </h1>
          <p className="text-xl md:text-2xl text-cyan-200 font-light tracking-wide">
            Explore NASA's Gigapixel Universe with AI-Powered Precision
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col md:flex-row gap-8 items-center"
        >
          <motion.button
            onClick={() => navigate('/login/user')}
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(59, 130, 246, 0.6)' }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-12 py-6 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-xl text-white text-xl font-semibold overflow-hidden transition-all duration-300 hover:from-blue-500 hover:to-cyan-400 shadow-lg hover:shadow-cyan-500/50"
          >
            <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></span>
            <span className="relative flex items-center gap-3">
              <UserCircle className="w-8 h-8" />
              Login as Normal User
            </span>
          </motion.button>

          <motion.button
            onClick={() => navigate('/login/scientist')}
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(16, 185, 129, 0.6)' }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-12 py-6 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-xl text-white text-xl font-semibold overflow-hidden transition-all duration-300 hover:from-emerald-500 hover:to-teal-400 shadow-lg hover:shadow-emerald-500/50"
          >
            <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></span>
            <span className="relative flex items-center gap-3">
              <Telescope className="w-8 h-8" />
              Login as NASA Scientist
            </span>
          </motion.button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <p className="text-gray-400 text-sm">
            Experience the cosmos like never before with cutting-edge AI technology
          </p>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-blue-950/50 to-transparent pointer-events-none"></div>
    </div>
  );
};
