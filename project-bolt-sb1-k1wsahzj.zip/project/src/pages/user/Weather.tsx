import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Cloud, Wind, Droplets, Eye, Activity, Satellite } from 'lucide-react';

interface WeatherData {
  location: string;
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
}

interface SpaceEvent {
  id: string;
  title: string;
  category: string;
  date: string;
}

export const Weather: React.FC = () => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [spaceEvents, setSpaceEvents] = useState<SpaceEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWeatherData();
    fetchSpaceEvents();
  }, []);

  const fetchWeatherData = async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setWeatherData({
        location: 'Kennedy Space Center, FL',
        temp: 78,
        condition: 'Clear Sky',
        humidity: 65,
        windSpeed: 12,
        visibility: 10,
      });
    } catch (error) {
      console.error('Error fetching weather:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSpaceEvents = async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setSpaceEvents([
        { id: '1', title: 'Solar Flare Activity Detected', category: 'Solar', date: '2 hours ago' },
        { id: '2', title: 'Asteroid 2024XY Approaching', category: 'Asteroid', date: '5 hours ago' },
        { id: '3', title: 'Aurora Borealis Expected Tonight', category: 'Geomagnetic', date: '1 day ago' },
        { id: '4', title: 'International Space Station Pass', category: 'ISS', date: '2 days ago' },
      ]);
    } catch (error) {
      console.error('Error fetching space events:', error);
    }
  };

  return (
    <DashboardLayout role="normal_user">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Weather & Space Conditions</h1>
          <p className="text-gray-400">Real-time atmospheric and space weather data</p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-white">Current Weather</h2>
                  <Cloud className="w-8 h-8 text-blue-400" />
                </div>

                {weatherData && (
                  <>
                    <div className="text-center mb-6">
                      <p className="text-gray-400 mb-2">{weatherData.location}</p>
                      <p className="text-6xl font-bold text-white mb-2">{weatherData.temp}°F</p>
                      <p className="text-xl text-blue-300">{weatherData.condition}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                        <Droplets className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{weatherData.humidity}%</p>
                        <p className="text-xs text-gray-400">Humidity</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                        <Wind className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{weatherData.windSpeed} mph</p>
                        <p className="text-xs text-gray-400">Wind Speed</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-4 text-center">
                        <Eye className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{weatherData.visibility} mi</p>
                        <p className="text-xs text-gray-400">Visibility</p>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-white">Space Weather</h2>
                  <Satellite className="w-8 h-8 text-emerald-400" />
                </div>

                <div className="space-y-4">
                  <div className="bg-slate-900/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400">Solar Activity</span>
                      <Activity className="w-5 h-5 text-yellow-400" />
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-yellow-500 to-orange-500 w-3/4"></div>
                      </div>
                      <span className="text-white font-semibold">Moderate</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400">Geomagnetic Field</span>
                      <Activity className="w-5 h-5 text-green-400" />
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 w-1/2"></div>
                      </div>
                      <span className="text-white font-semibold">Quiet</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400">Radiation Storm</span>
                      <Activity className="w-5 h-5 text-blue-400" />
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 w-1/4"></div>
                      </div>
                      <span className="text-white font-semibold">Low</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Recent Space Events</h2>
              <div className="space-y-3">
                {spaceEvents.map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center gap-4 p-4 bg-slate-900/50 rounded-lg hover:bg-slate-900/70 transition-all cursor-pointer"
                  >
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <div className="flex-1">
                      <h3 className="text-white font-semibold mb-1">{event.title}</h3>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded">{event.category}</span>
                        <span className="text-gray-400">{event.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </motion.div>
    </DashboardLayout>
  );
};
