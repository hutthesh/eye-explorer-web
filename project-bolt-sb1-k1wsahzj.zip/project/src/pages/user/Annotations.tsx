import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { BookmarkPlus, Download, Trash2, Eye } from 'lucide-react';

export const Annotations: React.FC = () => {
  const [annotations] = useState([
    { id: '1', image: 'Andromeda Galaxy', notes: 'Interesting spiral structure detected', date: '2024-01-15', tags: ['galaxy', 'spiral'] },
    { id: '2', image: 'Mars Surface', notes: 'Potential water ice deposits', date: '2024-01-14', tags: ['mars', 'ice'] },
    { id: '3', image: 'Nebula NGC 7293', notes: 'Planetary nebula analysis', date: '2024-01-13', tags: ['nebula', 'planetary'] },
  ]);

  return (
    <DashboardLayout role="normal_user">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">My Annotations</h1>
          <p className="text-gray-400">Manage your saved annotations and notes</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {annotations.map((annotation) => (
            <motion.div
              key={annotation.id}
              whileHover={{ scale: 1.02 }}
              className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
            >
              <div className="w-full h-40 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg mb-4"></div>
              <h3 className="text-xl font-bold text-white mb-2">{annotation.image}</h3>
              <p className="text-gray-400 text-sm mb-3">{annotation.notes}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {annotation.tags.map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-blue-500/20 text-blue-300 text-xs rounded">{tag}</span>
                ))}
              </div>
              <div className="flex gap-2">
                <button className="flex-1 p-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white text-sm flex items-center justify-center gap-2">
                  <Eye className="w-4 h-4" />
                  View
                </button>
                <button className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-white">
                  <Download className="w-4 h-4" />
                </button>
                <button className="p-2 bg-red-600 hover:bg-red-500 rounded-lg text-white">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
