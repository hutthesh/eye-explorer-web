import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { useAuth } from '../../contexts/AuthContext';
import { Telescope, Image, Zap, TrendingUp } from 'lucide-react';

export const UserDashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { icon: Image, label: 'Images Explored', value: '127', color: 'from-blue-500 to-cyan-400' },
    { icon: Telescope, label: 'Annotations', value: '43', color: 'from-purple-500 to-pink-400' },
    { icon: Zap, label: 'AI Queries', value: '89', color: 'from-yellow-500 to-orange-400' },
    { icon: TrendingUp, label: 'Time-lapses', value: '12', color: 'from-green-500 to-emerald-400' },
  ];

  return (
    <DashboardLayout role="normal_user">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Welcome back, {user?.full_name || 'Explorer'}
          </h1>
          <p className="text-gray-400">Explore the universe with cutting-edge AI technology</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all"
              >
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${stat.color} flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-white mb-1">{stat.value}</h3>
                <p className="text-gray-400 text-sm">{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
          >
            <h2 className="text-2xl font-bold text-white mb-4">Recent Explorations</h2>
            <div className="space-y-4">
              {[1, 2, 3].map((item) => (
                <div key={item} className="flex items-center gap-4 p-4 bg-slate-900/50 rounded-lg hover:bg-slate-900/70 transition-all cursor-pointer">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg"></div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-1">Andromeda Galaxy M31</h3>
                    <p className="text-gray-400 text-sm">Explored 2 hours ago</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
          >
            <h2 className="text-2xl font-bold text-white mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button className="w-full p-4 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-semibold hover:from-blue-500 hover:to-cyan-400 transition-all text-left">
                Explore New Dataset
              </button>
              <button className="w-full p-4 bg-slate-700/50 border border-gray-600 rounded-lg text-white font-semibold hover:bg-slate-600/50 transition-all text-left">
                Ask AI Assistant
              </button>
              <button className="w-full p-4 bg-slate-700/50 border border-gray-600 rounded-lg text-white font-semibold hover:bg-slate-600/50 transition-all text-left">
                Generate Time-lapse
              </button>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
