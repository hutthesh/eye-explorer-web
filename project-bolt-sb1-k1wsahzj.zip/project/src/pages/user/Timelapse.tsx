import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Film, Play } from 'lucide-react';

export const Timelapse: React.FC = () => {
  return (
    <DashboardLayout role="normal_user">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold text-white mb-2">Time-lapse Generator</h1>
        <p className="text-gray-400 mb-8">Create stunning time-lapse videos from NASA imagery</p>
        <div className="bg-slate-800/50 p-8 rounded-xl border border-gray-700">
          <div className="flex items-center gap-4 mb-6">
            <Film className="w-8 h-8 text-blue-400" />
            <h2 className="text-2xl font-bold text-white">Generate New Time-lapse</h2>
          </div>
          <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-semibold flex items-center gap-2">
            <Play className="w-5 h-5" />
            Start Generation
          </button>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
