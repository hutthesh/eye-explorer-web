import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { useAuth } from '../../contexts/AuthContext';
import { User, Mail, Globe, Moon, Sun } from 'lucide-react';

export const Profile: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [language, setLanguage] = useState(user?.language || 'en');
  const [theme, setTheme] = useState(user?.theme || 'dark');

  const handleSave = async () => {
    await updateProfile({ full_name: fullName, email, language, theme });
  };

  return (
    <DashboardLayout role="normal_user">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Profile Settings</h1>
          <p className="text-gray-400">Manage your account information and preferences</p>
        </div>

        <div className="max-w-2xl">
          <div className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700 mb-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">{user?.full_name}</h2>
                <p className="text-gray-400">{user?.role === 'normal_user' ? 'Explorer' : 'NASA Scientist'}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-slate-900 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-slate-900 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Language</label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-slate-900 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Theme</label>
                <div className="flex gap-4">
                  <button
                    onClick={() => setTheme('dark')}
                    className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                      theme === 'dark' ? 'border-blue-500 bg-slate-900' : 'border-gray-600 bg-slate-800'
                    }`}
                  >
                    <Moon className="w-6 h-6 text-white mx-auto mb-2" />
                    <p className="text-white text-sm">Dark</p>
                  </button>
                  <button
                    onClick={() => setTheme('light')}
                    className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                      theme === 'light' ? 'border-blue-500 bg-slate-900' : 'border-gray-600 bg-slate-800'
                    }`}
                  >
                    <Sun className="w-6 h-6 text-white mx-auto mb-2" />
                    <p className="text-white text-sm">Light</p>
                  </button>
                </div>
              </div>

              <button
                onClick={handleSave}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-semibold hover:from-blue-500 hover:to-cyan-400 transition-all"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
