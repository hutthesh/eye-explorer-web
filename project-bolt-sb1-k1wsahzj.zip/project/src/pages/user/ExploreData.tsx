import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import OpenSeadragon from 'openseadragon';
import { ZoomIn, ZoomOut, RotateCw, Layers, Download, BookmarkPlus, Grid } from 'lucide-react';

export const ExploreData: React.FC = () => {
  const viewerRef = useRef<HTMLDivElement>(null);
  const [viewer, setViewer] = useState<any>(null);
  const [selectedImage, setSelectedImage] = useState('hubble');
  const [showLayers, setShowLayers] = useState(false);
  const [activeLayers, setActiveLayers] = useState<string[]>(['rgb']);

  const images = {
    hubble: {
      name: 'Hubble Deep Field',
      url: 'https://openseadragon.github.io/example-images/duomo/duomo.dzi',
    },
    mars: {
      name: 'Mars Surface',
      url: 'https://openseadragon.github.io/example-images/highsmith/highsmith.dzi',
    },
  };

  const layers = [
    { id: 'rgb', name: 'RGB Composite', color: 'from-red-500 to-blue-500' },
    { id: 'infrared', name: 'Infrared', color: 'from-red-500 to-orange-500' },
    { id: 'ultraviolet', name: 'Ultraviolet', color: 'from-purple-500 to-blue-500' },
    { id: 'xray', name: 'X-Ray', color: 'from-cyan-500 to-blue-500' },
  ];

  useEffect(() => {
    if (viewerRef.current && !viewer) {
      const osd = OpenSeadragon({
        element: viewerRef.current,
        tileSources: images[selectedImage as keyof typeof images].url,
        prefixUrl: 'https://openseadragon.github.io/openseadragon/images/',
        showNavigationControl: false,
        animationTime: 0.5,
        blendTime: 0.1,
        constrainDuringPan: true,
        maxZoomPixelRatio: 2,
        minZoomLevel: 0.8,
        visibilityRatio: 1,
        zoomPerScroll: 1.2,
      });

      setViewer(osd);
    }

    return () => {
      if (viewer) {
        viewer.destroy();
      }
    };
  }, []);

  useEffect(() => {
    if (viewer) {
      viewer.open(images[selectedImage as keyof typeof images].url);
    }
  }, [selectedImage, viewer]);

  const handleZoomIn = () => {
    if (viewer) {
      viewer.viewport.zoomBy(1.5);
      viewer.viewport.applyConstraints();
    }
  };

  const handleZoomOut = () => {
    if (viewer) {
      viewer.viewport.zoomBy(0.67);
      viewer.viewport.applyConstraints();
    }
  };

  const handleRotate = () => {
    if (viewer) {
      const currentRotation = viewer.viewport.getRotation();
      viewer.viewport.setRotation(currentRotation + 90);
    }
  };

  const handleReset = () => {
    if (viewer) {
      viewer.viewport.goHome();
      viewer.viewport.setRotation(0);
    }
  };

  const toggleLayer = (layerId: string) => {
    setActiveLayers((prev) =>
      prev.includes(layerId) ? prev.filter((l) => l !== layerId) : [...prev, layerId]
    );
  };

  return (
    <DashboardLayout role="normal_user">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="h-[calc(100vh-8rem)]"
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Gigapixel Image Explorer</h1>
            <p className="text-gray-400">Deep zoom and analyze NASA imagery</p>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={selectedImage}
              onChange={(e) => setSelectedImage(e.target.value)}
              className="px-4 py-2 bg-slate-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="hubble">Hubble Deep Field</option>
              <option value="mars">Mars Surface</option>
            </select>
          </div>
        </div>

        <div className="relative bg-slate-900 rounded-xl border border-gray-700 overflow-hidden" style={{ height: 'calc(100% - 80px)' }}>
          <div ref={viewerRef} className="w-full h-full"></div>

          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button
              onClick={handleZoomIn}
              className="p-3 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all"
              title="Zoom In"
            >
              <ZoomIn className="w-5 h-5" />
            </button>
            <button
              onClick={handleZoomOut}
              className="p-3 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all"
              title="Zoom Out"
            >
              <ZoomOut className="w-5 h-5" />
            </button>
            <button
              onClick={handleRotate}
              className="p-3 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all"
              title="Rotate"
            >
              <RotateCw className="w-5 h-5" />
            </button>
            <button
              onClick={handleReset}
              className="p-3 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all"
              title="Reset View"
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowLayers(!showLayers)}
              className="p-3 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all"
              title="Spectral Layers"
            >
              <Layers className="w-5 h-5" />
            </button>
          </div>

          <div className="absolute bottom-4 right-4 flex gap-2">
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white font-semibold transition-all flex items-center gap-2">
              <BookmarkPlus className="w-4 h-4" />
              Add Annotation
            </button>
            <button className="px-4 py-2 bg-slate-800/90 backdrop-blur-sm border border-gray-600 rounded-lg text-white hover:bg-slate-700 transition-all flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>

          {showLayers && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="absolute top-4 left-4 bg-slate-800/95 backdrop-blur-sm border border-gray-600 rounded-xl p-4 w-64"
            >
              <h3 className="text-white font-bold mb-3 flex items-center gap-2">
                <Layers className="w-5 h-5" />
                Spectral Layers
              </h3>
              <div className="space-y-2">
                {layers.map((layer) => (
                  <label key={layer.id} className="flex items-center gap-3 p-2 hover:bg-slate-700/50 rounded-lg cursor-pointer transition-all">
                    <input
                      type="checkbox"
                      checked={activeLayers.includes(layer.id)}
                      onChange={() => toggleLayer(layer.id)}
                      className="w-4 h-4 rounded border-gray-600 bg-slate-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-0"
                    />
                    <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${layer.color}`}></div>
                    <span className="text-white text-sm">{layer.name}</span>
                  </label>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
