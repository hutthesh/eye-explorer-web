import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { useAuth } from '../../contexts/AuthContext';
import { User } from 'lucide-react';

export const ScientistProfile: React.FC = () => {
  const { user } = useAuth();

  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold text-white mb-8">Profile Settings</h1>
        <div className="max-w-2xl bg-slate-800/50 p-8 rounded-xl border border-gray-700">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-emerald-600 to-teal-500 flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{user?.full_name}</h2>
              <p className="text-gray-400">NASA Scientist</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
              <input
                type="email"
                value={user?.email}
                readOnly
                className="w-full px-4 py-3 bg-slate-900 border border-gray-600 rounded-lg text-white"
              />
            </div>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
