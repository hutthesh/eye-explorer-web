import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

export const Analytics: React.FC = () => {
  const data = [
    { name: 'Jan', datasets: 24, models: 8 },
    { name: 'Feb', datasets: 32, models: 12 },
    { name: 'Mar', datasets: 28, models: 10 },
    { name: 'Apr', datasets: 45, models: 15 },
    { name: 'May', datasets: 38, models: 13 },
  ];

  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold text-white mb-2">Data Analytics</h1>
        <p className="text-gray-400 mb-8">Comprehensive research analytics and insights</p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-800/50 p-6 rounded-xl border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-4">Research Activity</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip contentStyle={{ backgroundColor: '#1E293B', border: '1px solid #374151' }} />
                <Legend />
                <Bar dataKey="datasets" fill="#10B981" />
                <Bar dataKey="models" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-slate-800/50 p-6 rounded-xl border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-4">Temporal Analysis</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip contentStyle={{ backgroundColor: '#1E293B', border: '1px solid #374151' }} />
                <Legend />
                <Line type="monotone" dataKey="datasets" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="models" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
