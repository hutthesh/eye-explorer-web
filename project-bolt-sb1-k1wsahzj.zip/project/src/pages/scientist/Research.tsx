import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { FileText } from 'lucide-react';

export const Research: React.FC = () => {
  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
          <FileText className="w-10 h-10" />
          Research Insights
        </h1>
        <p className="text-gray-400 mb-8">AI-generated research summaries and insights</p>
        <div className="bg-slate-800/50 p-12 rounded-xl border border-gray-700 text-center">
          <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Research insights will appear here</p>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
