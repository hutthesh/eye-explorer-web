import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Upload, Database, Eye, Download, Trash2 } from 'lucide-react';

export const DatasetExplorer: React.FC = () => {
  const [datasets] = useState([
    { id: '1', name: 'Mars Surface Imagery 2024', type: 'GeoTIFF', size: '2.4 GB', date: '2024-01-15' },
    { id: '2', name: 'Exoplanet Spectral Data', type: 'FITS', size: '1.8 GB', date: '2024-01-14' },
    { id: '3', name: 'Solar Flare Analysis', type: 'CSV', size: '450 MB', date: '2024-01-13' },
  ]);

  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Dataset Explorer</h1>
            <p className="text-gray-400">Manage and analyze your research datasets</p>
          </div>
          <button className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg text-white font-semibold hover:from-emerald-500 hover:to-teal-400 transition-all flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload Dataset
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {datasets.map((dataset) => (
            <motion.div
              key={dataset.id}
              whileHover={{ scale: 1.01 }}
              className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700 flex items-center gap-6"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg flex items-center justify-center">
                <Database className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-1">{dataset.name}</h3>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <span>{dataset.type}</span>
                  <span>•</span>
                  <span>{dataset.size}</span>
                  <span>•</span>
                  <span>{dataset.date}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-3 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white">
                  <Eye className="w-5 h-5" />
                </button>
                <button className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg text-white">
                  <Download className="w-5 h-5" />
                </button>
                <button className="p-3 bg-red-600 hover:bg-red-500 rounded-lg text-white">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
