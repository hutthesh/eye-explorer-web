import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Brain, Upload, Play, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const AIModels: React.FC = () => {
  const [models] = useState([
    { id: '1', name: 'Crater Detection CNN', accuracy: 94.5, type: 'TensorFlow', status: 'Ready' },
    { id: '2', name: 'Galaxy Classification', accuracy: 89.2, type: 'PyTorch', status: 'Training' },
    { id: '3', name: 'Exoplanet Predictor', accuracy: 91.8, type: 'TensorFlow', status: 'Ready' },
  ]);

  const accuracyData = [
    { epoch: 1, train: 65, val: 62 },
    { epoch: 5, train: 78, val: 75 },
    { epoch: 10, train: 85, val: 82 },
    { epoch: 15, train: 90, val: 87 },
    { epoch: 20, train: 94, val: 91 },
  ];

  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">AI Model Management</h1>
            <p className="text-gray-400">Upload, train, and deploy machine learning models</p>
          </div>
          <button className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg text-white font-semibold hover:from-emerald-500 hover:to-teal-400 transition-all flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload Model
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {models.map((model) => (
            <motion.div
              key={model.id}
              whileHover={{ scale: 1.02 }}
              className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-bold">{model.name}</h3>
                  <p className="text-gray-400 text-sm">{model.type}</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 text-sm">Accuracy</span>
                  <span className="text-white font-bold">{model.accuracy}%</span>
                </div>
                <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
                    style={{ width: `${model.accuracy}%` }}
                  ></div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className={`px-3 py-1 rounded-full text-xs ${model.status === 'Ready' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                  {model.status}
                </span>
                <button className="p-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white">
                  <Play className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="bg-slate-800/50 backdrop-blur-xl rounded-xl p-6 border border-gray-700">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
            <h2 className="text-2xl font-bold text-white">Training Metrics</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={accuracyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="epoch" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip contentStyle={{ backgroundColor: '#1E293B', border: '1px solid #374151' }} />
              <Legend />
              <Line type="monotone" dataKey="train" stroke="#10B981" strokeWidth={2} name="Training Accuracy" />
              <Line type="monotone" dataKey="val" stroke="#3B82F6" strokeWidth={2} name="Validation Accuracy" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
