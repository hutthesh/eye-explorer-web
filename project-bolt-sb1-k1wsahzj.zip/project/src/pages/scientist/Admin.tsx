import React from 'react';
import { motion } from 'framer-motion';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Settings } from 'lucide-react';

export const Admin: React.FC = () => {
  return (
    <DashboardLayout role="nasa_scientist">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold text-white mb-2">Admin Tools</h1>
        <p className="text-gray-400 mb-8">System configuration and management</p>
        <div className="bg-slate-800/50 p-12 rounded-xl border border-gray-700 text-center">
          <Settings className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Admin tools and settings</p>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};
