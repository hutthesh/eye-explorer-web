import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'normal_user' | 'nasa_scientist';
  avatar_url?: string;
  theme: 'light' | 'dark';
  language: string;
  two_fa_enabled: boolean;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string, role: 'normal_user' | 'nasa_scientist') => Promise<{ success: boolean; requiresTwoFA?: boolean; message?: string }>;
  verifyTwoFA: (code: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

const DEMO_USERS = {
  'demo@gmail.com': {
    id: 'demo-user-1',
    email: 'demo@gmail.com',
    password: 'demo@12345',
    full_name: 'Demo User',
    role: 'normal_user' as const,
    theme: 'dark' as const,
    language: 'en',
    two_fa_enabled: false,
  },
  'scientist@nasa.gov': {
    id: 'scientist-1',
    email: 'scientist@nasa.gov',
    password: 'nasa@2024',
    full_name: 'Dr. Jane Smith',
    role: 'nasa_scientist' as const,
    theme: 'dark' as const,
    language: 'en',
    two_fa_enabled: true,
  },
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        localStorage.removeItem('user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string, role: 'normal_user' | 'nasa_scientist') => {
    const demoUser = DEMO_USERS[email as keyof typeof DEMO_USERS];

    if (demoUser && demoUser.password === password && demoUser.role === role) {
      const { password: _, ...userWithoutPassword } = demoUser;

      if (demoUser.two_fa_enabled) {
        setPendingUser(userWithoutPassword);
        return { success: true, requiresTwoFA: true };
      }

      setUser(userWithoutPassword);
      localStorage.setItem('user', JSON.stringify(userWithoutPassword));
      return { success: true };
    }

    return { success: false, message: 'Invalid email or password' };
  };

  const verifyTwoFA = async (code: string) => {
    if (code === '123456' && pendingUser) {
      setUser(pendingUser);
      localStorage.setItem('user', JSON.stringify(pendingUser));
      setPendingUser(null);
      return { success: true };
    }

    return { success: false, message: 'Invalid 2FA code' };
  };

  const logout = () => {
    setUser(null);
    setPendingUser(null);
    localStorage.removeItem('user');
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const resetPassword = async (email: string) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { success: true, message: 'Password reset email sent successfully' };
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, verifyTwoFA, logout, updateProfile, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};
